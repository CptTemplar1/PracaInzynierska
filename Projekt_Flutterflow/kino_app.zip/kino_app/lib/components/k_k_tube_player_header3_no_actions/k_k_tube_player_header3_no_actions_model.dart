import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'k_k_tube_player_header3_no_actions_widget.dart'
    show KKTubePlayerHeader3NoActionsWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class KKTubePlayerHeader3NoActionsModel
    extends FlutterFlowModel<KKTubePlayerHeader3NoActionsWidget> {
  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
