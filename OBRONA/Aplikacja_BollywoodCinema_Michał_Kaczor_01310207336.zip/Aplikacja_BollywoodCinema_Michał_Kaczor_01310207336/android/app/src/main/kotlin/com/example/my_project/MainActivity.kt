package com.kaczor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
